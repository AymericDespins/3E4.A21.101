import Exploration from '../models/exploration.model.js';

class ExplorationsRepository {
    
}

export default new ExplorationsRepository();